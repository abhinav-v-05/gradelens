"""Vercel FastAPI entrypoint."""
import sys
from pathlib import Path

# The backend modules use ``app.*`` imports. Vercel starts this entrypoint
# from the repository root, so make the backend package directory explicit.
BACKEND_DIR = Path(__file__).resolve().parent / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from backend.app.main import app

