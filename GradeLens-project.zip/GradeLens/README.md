# GradeLens

**Student Academic Performance Analysis and Prediction Using Machine Learning and Neural Networks**  
*See the patterns. Understand the performance. Shape the future.*

GradeLens is a React and FastAPI academic analysis application using the official UCI Student Performance dataset. It provides independent Mathematics and Portuguese cohorts, six model pipelines, two prior-grade experiments, data exploration, model evaluation, individual estimates, and an SQLite prediction history.

## Problem and objectives

Academic results reflect a complex mix of prior achievement, study habits, family context, attendance, and other factors. GradeLens offers an educational mini-project for inspecting these patterns and comparing reproducible classifiers. It is intended for demonstration and exploration, not student ranking or consequential decisions.

## Dataset

The app downloads and caches `student-mat.csv` and `student-por.csv` from the [official UCI Student Performance dataset](https://archive.ics.uci.edu/dataset/320/student+performance). Choose either source cohort separately or use General Student Data, which pools their rows and retains course as a model input. It does not assume the two files are paired student records. Source columns and row counts are loaded from the downloaded files; no sample records or substitute metrics are generated. G3 (0–20) is the target. Project-defined categories are Low (0–9), Average (10–13), and High (14–20). G3 is always excluded from input features.

## Models and method

1. Logistic Regression (`max_iter=1200`, balanced classes)
2. Decision Tree (`max_depth=8`, `min_samples_leaf=3`)
3. Random Forest (250 trees, `min_samples_leaf=2`)
4. K-Nearest Neighbors (`k=7`, distance weights)
5. RBF Support Vector Machine (`C=1`, calibrated probabilities)
6. MLP neural network (64 and 32 ReLU hidden units, Adam, 600 iteration cap)

Categorical values are imputed and one-hot encoded; numeric values are median-imputed. Logistic Regression, KNN, SVM, and MLP use standard scaling; tree models do not. Preprocessors live inside sklearn pipelines and are fitted on training folds only. A fixed seed and stratified 80/20 train-test split are used. Stratified five-fold cross-validation runs on the training set. Reports include accuracy, macro and weighted precision/recall/F1, confusion matrix, class report, training/prediction duration, cross-validation accuracy, and macro one-vs-rest ROC-AUC where available.

Experiment A retains G1 and G2. Experiment B removes both. Both are fitted independently with identical split seed and preprocessing rules. Association and feature views are descriptive; correlation does not establish causation. Prediction probabilities are model confidence estimates, not guarantees.

## Architecture

- `frontend/`: React 18, Vite, Tailwind CSS, Recharts, Lucide, Axios, React Router. Vercel installs it with `npm ci` using the included package-lock.json.
- `backend/app/`: FastAPI endpoints, UCI loader, sklearn pipelines and training, prediction, SQLite persistence.
- `backend/data/`: downloaded UCI CSV cache.
- `backend/saved_models/`: subject/experiment-specific joblib pipelines and result JSON.

## macOS setup

Requirements: Python 3.10+ and Node.js 20+.

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8003
```

In another terminal:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5176. The backend API is at http://localhost:8003 and interactive API docs are at http://localhost:8003/docs. The first dataset load and model training need internet access for the UCI archive and can take a little time, especially for MLP and cross-validation. To build the frontend, run `npm run build` from `frontend`.

## API

- `GET /api/health`
- `GET /api/dataset/overview?subject=mathematics|portuguese`
- `GET /api/dataset/source`, `/api/dataset/preview`, `/api/dataset/statistics`
- `POST /api/dataset/refresh?subject=...`
- `POST /api/train` with `{"subject":"mathematics","experiment":"with_grades"}`
- `GET /api/models`, `/api/models/results`, `/api/models/{model_name}/metrics`
- `POST /api/predict` with subject, experiment, model, and student feature object
- `GET /api/predictions/history`, `DELETE /api/predictions/{prediction_id}`
- `POST/GET /api/manual/records`, `PUT/DELETE /api/manual/records/{record_id}`
- `GET /api/experiments`, `POST /api/experiments/run?subject=...`

## Limitations and future work

The original cohort is historical and context-specific; categories simplify a continuous grade. Some class distributions are imbalanced, and held-out results on a small cohort may vary. The manual labelled-record builder stores validated records separately but does not train a model from them. Feature exploration currently provides numeric correlations; permutation importance, broader filters, and advanced subgroup analysis are future enhancements. The dashboard is designed for local educational demonstrations; deploy behind suitable authentication and privacy controls before multi-user use.

## References

- Cortez, P. (2014). Student Performance. UCI Machine Learning Repository. https://doi.org/10.24432/C5TG7T
- UCI Machine Learning Repository dataset page: https://archive.ics.uci.edu/dataset/320/student+performance
- Scikit-learn documentation: https://scikit-learn.org/stable/
