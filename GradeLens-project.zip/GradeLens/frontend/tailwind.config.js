export default {content:['./index.html','./src/**/*.{js,jsx}'],theme:{extend:{colors:{chartreuse:'#D9EE78',olive:'#858F50',ivory:'#F6F5EC',forest:'#202B28',sage:'#B9D8CC'}}},plugins:[]};
