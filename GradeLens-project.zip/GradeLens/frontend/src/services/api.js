import axios from 'axios';
const api=axios.create({baseURL:import.meta.env.VITE_API_URL||'/api',timeout:120000});
export const errorMessage=e=>e?.response?.data?.detail||e.message||'Something went wrong';
export default api;
