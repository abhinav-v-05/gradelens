import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             precision_score, recall_score, f1_score, roc_auc_score)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from app.core.config import BUNDLED_MODEL_DIR, EXPERIMENTS, MODEL_DIR, SEED
from app.dataset.loader import load_dataset
from app.preprocessing.pipeline import make_pipeline

MODELS = {
    "Logistic Regression": (LogisticRegression(max_iter=1200, class_weight="balanced", random_state=SEED), True),
    "Decision Tree": (DecisionTreeClassifier(max_depth=8, min_samples_leaf=3, class_weight="balanced", random_state=SEED), False),
    "Random Forest": (RandomForestClassifier(n_estimators=250, min_samples_leaf=2, class_weight="balanced", random_state=SEED, n_jobs=-1), False),
    "K-Nearest Neighbors": (KNeighborsClassifier(n_neighbors=7, weights="distance"), True),
    "Support Vector Machine": (SVC(C=1.0, kernel="rbf", probability=True, class_weight="balanced", random_state=SEED), True),
    "MLP Neural Network": (MLPClassifier(hidden_layer_sizes=(64, 32), activation="relu", solver="adam", alpha=0.001, learning_rate_init=0.001, max_iter=600, early_stopping=False, random_state=SEED), True),
}


def category(grades):
    return np.where(grades <= 9, "Low", np.where(grades <= 13, "Average", "High"))


def train(subject="mathematics", experiment="with_grades"):
    if experiment not in EXPERIMENTS:
        raise ValueError("Experiment must be with_grades or without_grades")
    frame = load_dataset(subject).drop_duplicates().reset_index(drop=True)
    y = pd.Series(category(frame.pop("G3")), name="category")
    if experiment == "without_grades":
        frame = frame.drop(columns=["G1", "G2"])
    X_train, X_test, y_train, y_test = train_test_split(frame, y, test_size=.2, random_state=SEED, stratify=y)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    for name, (estimator, scale) in MODELS.items():
        pipeline = make_pipeline(clone(estimator), X_train, scale)
        start = time.perf_counter()
        pipeline.fit(X_train, y_train)
        training_time = time.perf_counter() - start
        start = time.perf_counter()
        pred = pipeline.predict(X_test)
        prediction_time = time.perf_counter() - start
        try:
            cv_scores = cross_val_score(make_pipeline(clone(estimator), X_train, scale), X_train, y_train, cv=cv, scoring="accuracy", n_jobs=1)
            cv_acc, cv_std = float(cv_scores.mean()), float(cv_scores.std())
        except Exception:
            cv_acc, cv_std = None, None
        try:
            auc = float(roc_auc_score(y_test, pipeline.predict_proba(X_test), labels=pipeline.classes_.tolist(), multi_class="ovr", average="macro"))
        except Exception:
            auc = None
        result = {"model": name, "subject": subject, "experiment": experiment,
            "accuracy": float(accuracy_score(y_test, pred)),
            "precision_macro": float(precision_score(y_test, pred, average="macro", zero_division=0)),
            "precision_weighted": float(precision_score(y_test, pred, average="weighted", zero_division=0)),
            "recall_macro": float(recall_score(y_test, pred, average="macro", zero_division=0)),
            "recall_weighted": float(recall_score(y_test, pred, average="weighted", zero_division=0)),
            "f1_macro": float(f1_score(y_test, pred, average="macro", zero_division=0)),
            "f1_weighted": float(f1_score(y_test, pred, average="weighted", zero_division=0)),
            "confusion_matrix": confusion_matrix(y_test, pred, labels=["Low", "Average", "High"]).tolist(),
            "classification_report": classification_report(y_test, pred, labels=["Low", "Average", "High"], output_dict=True, zero_division=0),
            "training_time": training_time, "prediction_time": prediction_time,
            "cv_accuracy": cv_acc, "cv_std": cv_std, "roc_auc_macro": auc,
            "classes": pipeline.classes_.tolist(), "test_actual": y_test.tolist(), "test_predicted": pred.tolist()}
        path = MODEL_DIR / f"{subject}_{experiment}_{name.lower().replace(' ', '_')}.joblib"
        import joblib
        joblib.dump({"pipeline": pipeline, "columns": frame.columns.tolist()}, path)
        result["model_path"] = str(path)
        results.append(result)
    summary = {"subject": subject, "experiment": experiment, "records": len(frame), "test_records": len(y_test),
               "models": results, "best_model": max(results, key=lambda x:x["accuracy"])["model"],
               "lowest_model": min(results, key=lambda x:x["accuracy"])["model"]}
    (MODEL_DIR / f"{subject}_{experiment}_results.json").write_text(json.dumps(summary))
    return summary


def get_results(subject="mathematics", experiment="with_grades"):
    filename = f"{subject}_{experiment}_results.json"
    path = MODEL_DIR / filename
    if not path.exists():
        path = BUNDLED_MODEL_DIR / filename
    if not path.exists():
        return None
    return json.loads(path.read_text())
