import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ON_VERCEL = os.environ.get("VERCEL") == "1"
RUNTIME_DIR = Path("/tmp/gradelens") if ON_VERCEL else ROOT
DATA_DIR = RUNTIME_DIR / "data"
MODEL_DIR = RUNTIME_DIR / "saved_models"
BUNDLED_DATA_DIR = ROOT / "data"
BUNDLED_MODEL_DIR = ROOT / "saved_models"
DB_PATH = RUNTIME_DIR / "gradelens.sqlite3"
UCI_SOURCE = "https://archive.ics.uci.edu/dataset/320/student+performance"
UCI_ZIP = "https://archive.ics.uci.edu/static/public/320/student+performance.zip"
SEED = 42
SUBJECTS = {"mathematics": "student-mat.csv", "portuguese": "student-por.csv"}
EXPERIMENTS = {
    "with_grades": "With Previous Grades",
    "without_grades": "Without Previous Grades",
}
