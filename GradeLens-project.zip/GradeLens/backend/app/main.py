import json
from pathlib import Path

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from app.core.config import BUNDLED_MODEL_DIR, EXPERIMENTS, MODEL_DIR, UCI_SOURCE
from app.database import store
from app.dataset.loader import load_dataset, overview
from app.models.training import MODELS, get_results, train

app = FastAPI(title="GradeLens API", version="1.0.0", description="Student performance analysis and prediction")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:5174", "http://127.0.0.1:5174"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
store.init_db()


class TrainRequest(BaseModel):
    subject: str = "mathematics"
    experiment: str = "with_grades"


class PredictionRequest(BaseModel):
    subject: str
    experiment: str
    model: str
    student: dict = Field(min_length=1)


class ManualRecord(BaseModel):
    record: dict = Field(min_length=1)


def validate_selection(subject, experiment):
    if subject not in ("general", "mathematics", "portuguese"):
        raise HTTPException(422, "Cohort must be general, mathematics, or portuguese")
    if experiment not in EXPERIMENTS:
        raise HTTPException(422, "Unknown experiment")


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "GradeLens API"}


@app.get("/api/dataset/overview")
def dataset_overview(subject: str = "mathematics"):
    validate_selection(subject, "with_grades")
    try:
        return overview(subject)
    except Exception as e:
        raise HTTPException(503, str(e))


@app.get("/api/dataset/source")
def dataset_source():
    return {"source": UCI_SOURCE, "citation": "Cortez, P. (2014). Student Performance. UCI Machine Learning Repository."}


@app.get("/api/dataset/preview")
def dataset_preview(subject: str = "mathematics", limit: int = Query(10, ge=1, le=100)):
    validate_selection(subject, "with_grades")
    try:
        frame = load_dataset(subject)
        return {"columns": frame.columns.tolist(), "rows": frame.head(limit).where(pd.notna(frame.head(limit)), None).to_dict(orient="records")}
    except Exception as e:
        raise HTTPException(503, str(e))


@app.get("/api/dataset/statistics")
def dataset_statistics(subject: str = "mathematics"):
    validate_selection(subject, "with_grades")
    try:
        frame = load_dataset(subject)
        grades = frame.G3
        summary = frame.describe(include="all").fillna("").to_dict()
        counts = pd.Series(pd.cut(grades, [-1, 9, 13, 20], labels=["Low", "Average", "High"])).value_counts().to_dict()
        return {"summary": summary, "missing": frame.isna().sum().to_dict(), "duplicates": int(frame.duplicated().sum()), "grade_distribution": counts,
                "age_distribution": frame.age.value_counts().sort_index().to_dict(), "studytime_distribution": frame.studytime.value_counts().sort_index().to_dict(),
                "absence_distribution": frame.absences.value_counts().sort_index().head(30).to_dict(), "correlations": frame.select_dtypes("number").corr().round(3).fillna(0).to_dict()}
    except Exception as e:
        raise HTTPException(503, str(e))


@app.post("/api/dataset/refresh")
def dataset_refresh(subject: str = "mathematics"):
    validate_selection(subject, "with_grades")
    try:
        frame = load_dataset(subject, refresh=True)
        return overview(subject) | {"refreshed": True, "records": len(frame)}
    except Exception as e:
        raise HTTPException(503, str(e))


@app.post("/api/train")
def train_models(req: TrainRequest):
    validate_selection(req.subject, req.experiment)
    try:
        return train(req.subject, req.experiment)
    except Exception as e:
        raise HTTPException(500, f"Training failed: {e}")


@app.get("/api/models")
def models():
    return {"models": list(MODELS), "experiments": EXPERIMENTS}


@app.get("/api/models/results")
def model_results(subject: str = "mathematics", experiment: str = "with_grades"):
    validate_selection(subject, experiment)
    result = get_results(subject, experiment)
    return result or {"subject": subject, "experiment": experiment, "models": [], "trained": False}


@app.get("/api/models/{model_name}/metrics")
def model_metrics(model_name: str, subject: str = "mathematics", experiment: str = "with_grades"):
    result = get_results(subject, experiment)
    if not result:
        raise HTTPException(404, "Train this experiment before requesting model metrics")
    model = next((m for m in result["models"] if m["model"].lower().replace(" ", "-") == model_name.lower()), None)
    if not model:
        raise HTTPException(404, "Model not found")
    return model


@app.post("/api/predict")
def predict(req: PredictionRequest):
    validate_selection(req.subject, req.experiment)
    if req.model not in MODELS:
        raise HTTPException(422, "Unknown model")
    filename = f"{req.subject}_{req.experiment}_{req.model.lower().replace(' ', '_')}.joblib"
    path = MODEL_DIR / filename
    if not path.exists():
        path = BUNDLED_MODEL_DIR / filename
    if not path.exists():
        raise HTTPException(409, "Train the selected subject and experiment before predicting")
    try:
        artifact = joblib.load(path)
        student = dict(req.student)
        if req.experiment == "without_grades":
            student.pop("G1", None); student.pop("G2", None)
        row = pd.DataFrame([{c: student.get(c) for c in artifact["columns"]}], columns=artifact["columns"])
        pipeline = artifact["pipeline"]
        prediction = pipeline.predict(row)[0]
        probs = pipeline.predict_proba(row)[0] if hasattr(pipeline, "predict_proba") else None
        distribution = {str(c): float(p) for c, p in zip(pipeline.classes_, probs)} if probs is not None else None
        confidence = max(distribution.values()) if distribution else None
        summary = {k: v for k, v in student.items() if k in ("age", "sex", "studytime", "failures", "absences", "G1", "G2")}
        pid = store.save_prediction(req.model, req.subject, req.experiment, str(prediction), summary)
        return {"id": pid, "category": str(prediction), "model": req.model, "subject": req.subject, "experiment": req.experiment, "probabilities": distribution, "confidence": confidence, "summary": summary,
                "explanation": "This estimate reflects patterns in the selected UCI dataset and is not a guaranteed outcome."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(422, f"Prediction input could not be processed: {e}")


@app.get("/api/predictions/history")
def prediction_history():
    return store.history()


@app.delete("/api/predictions/{prediction_id}")
def delete_prediction(prediction_id: int):
    if not store.delete_prediction(prediction_id):
        raise HTTPException(404, "Prediction not found")
    return {"deleted": prediction_id}


@app.post("/api/manual/records")
def create_manual_record(req: ManualRecord):
    payload = req.record
    if "G3" not in payload or not isinstance(payload["G3"], (int, float)) or not 0 <= payload["G3"] <= 20:
        raise HTTPException(422, "A numeric G3 from 0 to 20 is required")
    return {"id": store.add_manual(payload), "record": payload}


@app.get("/api/manual/records")
def get_manual_records():
    return store.manual_records()


@app.put("/api/manual/records/{record_id}")
def update_manual_record(record_id: int, req: ManualRecord):
    if "G3" not in req.record or not isinstance(req.record["G3"], (int, float)) or not 0 <= req.record["G3"] <= 20:
        raise HTTPException(422, "A numeric G3 from 0 to 20 is required")
    if not store.add_manual(req.record, record_id):
        raise HTTPException(404, "Manual record not found")
    return {"id": record_id, "record": req.record}


@app.delete("/api/manual/records/{record_id}")
def delete_manual_record(record_id: int):
    if not store.delete_manual(record_id):
        raise HTTPException(404, "Manual record not found")
    return {"deleted": record_id}


@app.get("/api/experiments")
def experiments(subject: str = "mathematics"):
    validate_selection(subject, "with_grades")
    return {key: get_results(subject, key) or {"subject": subject, "experiment": key, "models": [], "trained": False} for key in EXPERIMENTS}


@app.post("/api/experiments/run")
def run_experiments(subject: str = "mathematics"):
    validate_selection(subject, "with_grades")
    try:
        return {key: train(subject, key) for key in EXPERIMENTS}
    except Exception as e:
        raise HTTPException(500, f"Experiment training failed: {e}")
