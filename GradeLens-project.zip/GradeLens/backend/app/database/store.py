import json
import sqlite3
from datetime import datetime, timezone

from app.core.config import DB_PATH


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as db:
        db.execute("CREATE TABLE IF NOT EXISTS predictions (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, model TEXT NOT NULL, subject TEXT NOT NULL, experiment TEXT NOT NULL, category TEXT NOT NULL, input_summary TEXT NOT NULL)")
        db.execute("CREATE TABLE IF NOT EXISTS manual_records (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)")


def save_prediction(model, subject, experiment, category, summary):
    with connect() as db:
        cur = db.execute("INSERT INTO predictions(created_at,model,subject,experiment,category,input_summary) VALUES(?,?,?,?,?,?)",
                         (datetime.now(timezone.utc).isoformat(), model, subject, experiment, category, json.dumps(summary)))
        return cur.lastrowid


def history():
    with connect() as db:
        return [dict(r) | {"input_summary": json.loads(r["input_summary"])} for r in db.execute("SELECT * FROM predictions ORDER BY id DESC")]


def delete_prediction(pid):
    with connect() as db:
        return db.execute("DELETE FROM predictions WHERE id=?", (pid,)).rowcount > 0


def manual_records():
    with connect() as db:
        return [dict(r) | {"record": json.loads(r["payload"])} for r in db.execute("SELECT * FROM manual_records ORDER BY id")]


def add_manual(payload, rid=None):
    with connect() as db:
        if rid is None:
            return db.execute("INSERT INTO manual_records(payload) VALUES(?)", (json.dumps(payload),)).lastrowid
        cur = db.execute("UPDATE manual_records SET payload=? WHERE id=?", (json.dumps(payload), rid))
        return cur.rowcount > 0


def delete_manual(rid):
    with connect() as db:
        return db.execute("DELETE FROM manual_records WHERE id=?", (rid,)).rowcount > 0
