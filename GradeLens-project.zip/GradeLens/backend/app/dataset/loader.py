import io
import zipfile
from urllib.request import urlopen

import pandas as pd

from app.core.config import BUNDLED_DATA_DIR, DATA_DIR, SUBJECTS, UCI_SOURCE, UCI_ZIP

REQUIRED = {"G1", "G2", "G3", "age", "sex", "studytime", "absences"}


def _valid(path):
    try:
        frame = pd.read_csv(path, sep=";")
        return REQUIRED.issubset(frame.columns) and len(frame) > 0
    except Exception:
        return False


def load_dataset(subject="mathematics", refresh=False):
    subject = subject.lower()
    if subject == "general":
        mathematics = load_dataset("mathematics", refresh=refresh).assign(course="mathematics")
        portuguese = load_dataset("portuguese", refresh=refresh).assign(course="portuguese")
        return pd.concat([mathematics, portuguese], ignore_index=True)
    if subject not in SUBJECTS:
        raise ValueError("Cohort must be general, mathematics, or portuguese")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = DATA_DIR / SUBJECTS[subject]
    bundled_path = BUNDLED_DATA_DIR / SUBJECTS[subject]
    if not refresh and not _valid(path) and _valid(bundled_path):
        path.write_bytes(bundled_path.read_bytes())
    if refresh or not _valid(path):
        try:
            with urlopen(UCI_ZIP, timeout=30) as response:
                archive = zipfile.ZipFile(io.BytesIO(response.read()))
            member = next((n for n in archive.namelist() if n.endswith(SUBJECTS[subject])), None)
            if member is not None:
                payload = archive.read(member)
            else:
                nested_name = next(n for n in archive.namelist() if n.endswith("student.zip"))
                nested = zipfile.ZipFile(io.BytesIO(archive.read(nested_name)))
                member = next(n for n in nested.namelist() if n.endswith(SUBJECTS[subject]))
                payload = nested.read(member)
            path.write_bytes(payload)
        except Exception as exc:
            if not _valid(path):
                raise RuntimeError(f"Could not download or validate the official UCI dataset: {exc}") from exc
    if not _valid(path):
        raise RuntimeError(f"Dataset file failed validation: {path}")
    frame = pd.read_csv(path, sep=";")
    return frame


def overview(subject="mathematics"):
    frame = load_dataset(subject)
    return {"name": "UCI Student Performance", "subject": subject, "records": len(frame),
            "columns": len(frame.columns), "features": len(frame.columns) - 1,
            "feature_names": [c for c in frame.columns if c != "G3"], "source": UCI_SOURCE,
            "missing_values": int(frame.isna().sum().sum()), "duplicates": int(frame.duplicated().sum())}
