from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    assert client.get('/api/health').json()['status'] == 'ok'


def test_model_catalog():
    data = client.get('/api/models').json()
    assert len(data['models']) == 6


def test_invalid_subject():
    assert client.get('/api/dataset/overview', params={'subject': 'history'}).status_code in (422, 503)


def test_manual_record_validation():
    assert client.post('/api/manual/records', json={'record': {'G3': 21}}).status_code == 422
