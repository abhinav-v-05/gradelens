# GradeLens project status

## Implemented

- React/Vite responsive dashboard with all ten requested navigation areas.
- FastAPI backend and live frontend REST integration.
- Automatic UCI ZIP download, subject-specific caching, offline cache validation, source reference, and refresh route.
- Six real sklearn classifiers with train-only preprocessing, stratified holdout, cross-validation, detailed metrics, per-experiment artifacts.
- With-grades and without-grades experiment variants.
- Individual prediction from saved pipelines, probability distribution, confidence estimate, and history storage.
- SQLite prediction history and CRUD routes for a separate manually labelled record collection.
- Dataset preview, statistics, distributions, numeric correlations, model metrics and confusion/class reports.
- README, API docs via FastAPI, backend smoke tests.

## Verification state

Frontend production build passed. Backend health and dataset overview endpoints respond successfully; official Mathematics (395 rows) and Portuguese (649 rows) UCI records are cached locally. A real Mathematics / With Previous Grades training run completed for all six models, including the MLP. Server processes are currently running on ports 5173 and 8000.

## Known scope limits

- Feature analysis currently renders descriptive numeric G3 correlations. Permutation importance and full distribution filters are not implemented.
- The manual labelled builder has API CRUD endpoints but no dedicated multi-record editor UI; manual entry refers to the individual prediction form.
- Bulk delete/clear-history is not exposed in the client.
- Frontend design uses Google Fonts as an optional remote enhancement; local system fallbacks remain available.
